<?php
/** include all databse classes */
require_once( DBPATH . 'DB_driver.php' );
require_once( DBPATH . 'DB_active_rec.php' );
require_once( DBPATH . 'DB_result.php' );
require_once( DBPATH . 'mysql_driver.php' );
require_once( DBPATH . 'mysql_result.php' );
?>