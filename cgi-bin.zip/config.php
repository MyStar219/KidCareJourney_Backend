<?php
// The name of the database
define('DB_NAME', 'db_carecenter');

// MySQL database username 
define('DB_USER', 'joshyong_upwork');

// MySQL database password 
define('DB_PASSWORD', 'qT8x{L9K!y[4');

// MySQL hostname 
define('DB_HOST', 'localhost');

// Table prefix
$table_prefix  = '';

// Table names
define('TBL_USERS', 'tbl_users');

?>